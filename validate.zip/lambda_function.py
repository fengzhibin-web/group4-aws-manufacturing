"""Group 4 / Phase 2: S3 CSV validation, DynamoDB job state, SQS submission.

Deploy this entire file as lambda_function.py in group4-validate.
Handler: lambda_function.lambda_handler
Environment: JOB_QUEUE_URL, JOB_TABLE_NAME=group4-mfg-jobs
"""
import csv
import hashlib
import io
import json
import os
from datetime import datetime, timezone
from urllib.parse import unquote_plus

import boto3
from botocore.exceptions import ClientError

s3 = boto3.client("s3")
sqs = boto3.client("sqs")
table = boto3.resource("dynamodb").Table(os.environ["JOB_TABLE_NAME"])
QUEUE_URL = os.environ["JOB_QUEUE_URL"]
MAX_BYTES = 10 * 1024 * 1024
PROCESS_VERSION = "v1"
REQUIRED_COLUMNS = {
    "timestamp", "machine_id", "shift", "product_id",
    "supplier_batch", "temperature", "defect_label"
}


def _now():
    return datetime.now(timezone.utc).isoformat()


def _save_json(bucket, key, obj):
    s3.put_object(
        Bucket=bucket,
        Key=key,
        Body=json.dumps(obj, ensure_ascii=False, indent=2).encode("utf-8"),
        ContentType="application/json",
    )


def _put_job_once(job):
    """Create a job record once; do not overwrite an existing completed job."""
    try:
        table.put_item(Item=job, ConditionExpression="attribute_not_exists(job_id)")
        return job, True
    except ClientError as exc:
        if exc.response["Error"]["Code"] != "ConditionalCheckFailedException":
            raise
        old = table.get_item(Key={"job_id": job["job_id"]}, ConsistentRead=True).get("Item")
        if not old:
            raise RuntimeError("Job was not found after conditional-create conflict")
        return old, False


def lambda_handler(event, context):
    if event.get("Event") == "s3:TestEvent":
        return {"message": "S3 test event ignored"}

    handled = []
    for rec in event.get("Records", []):
        bucket = rec["s3"]["bucket"]["name"]
        key = unquote_plus(rec["s3"]["object"]["key"])
        if not key.startswith("raw/") or not key.lower().endswith(".csv"):
            print(json.dumps({"stage": "validation", "skip": key}))
            continue

        raw = s3.get_object(Bucket=bucket, Key=key)["Body"].read(MAX_BYTES + 1)
        digest = hashlib.sha256(raw).hexdigest()
        # Idempotency key incorporates the content hash and processing version.
        # For this MVP the same content+version shares the same job ID, even if
        # the file was uploaded with another name.
        job_id = hashlib.sha256(f"{digest}:{PROCESS_VERSION}".encode()).hexdigest()[:16]
        errors = []
        if len(raw) > MAX_BYTES:
            errors.append("file exceeds 10 MiB")
        elif not raw:
            errors.append("empty file")
        else:
            try:
                text = raw.decode("utf-8-sig")
                reader = csv.DictReader(io.StringIO(text))
                columns = set(reader.fieldnames or [])
                missing = REQUIRED_COLUMNS - columns
                if missing:
                    errors.append("missing columns: " + ", ".join(sorted(missing)))
                if not errors and next(reader, None) is None:
                    errors.append("no data rows")
            except (UnicodeDecodeError, csv.Error) as exc:
                errors.append("CSV decoding/parsing failed: " + str(exc))

        status = "INVALID_INPUT" if errors else "VALIDATED"
        validation = {
            "job_id": job_id, "bucket": bucket, "key": key,
            "stage": "validation", "status": status,
            "errors": errors, "sha256": digest, "processing_version": PROCESS_VERSION,
        }
        _save_json(bucket, f"reports/{job_id}/validation.json", validation)

        existing, created = _put_job_once({
            "job_id": job_id,
            "status": status,
            "bucket": bucket,
            "file_key": key,
            "sha256": digest,
            "processing_version": PROCESS_VERSION,
            "validation_errors": errors,
            "created_at": _now(),
            "updated_at": _now(),
        })
        if not created:
            # The previous record can point to a different filename containing
            # the same bytes. Avoid overwriting it or re-running finished work.
            old_status = existing.get("status", "UNKNOWN")
            if old_status != "VALIDATED":
                print(json.dumps({"stage": "validation", "job_id": job_id,
                                  "status": "DUPLICATE_SKIPPED", "existing_status": old_status}))
                handled.append({"job_id": job_id, "status": old_status,
                                "duplicate": True})
                continue

        if not errors:
            # When a previous send failed and the S3 event is retried, allowing
            # a resend here is safer than permanently stranding a VALIDATED job.
            # Processing Lambda's conditional lease protects against duplicate work.
            sqs.send_message(
                QueueUrl=QUEUE_URL,
                MessageBody=json.dumps({
                    "job_id": job_id, "bucket": bucket, "key": key,
                    "sha256": digest, "processing_version": PROCESS_VERSION,
                }),
            )
            try:
                # The processor may have started already; never revert PROCESSING
                # or COMPLETED to QUEUED due to this write racing with the consumer.
                table.update_item(
                    Key={"job_id": job_id},
                    UpdateExpression="SET #st = :queued, updated_at = :now",
                    ConditionExpression="#st = :validated",
                    ExpressionAttributeNames={"#st": "status"},
                    ExpressionAttributeValues={
                        ":queued": "QUEUED", ":validated": "VALIDATED", ":now": _now()
                    },
                )
            except ClientError as exc:
                if exc.response["Error"]["Code"] != "ConditionalCheckFailedException":
                    raise

        print(json.dumps({"stage": "validation", "job_id": job_id,
                          "status": status, "errors": errors}, ensure_ascii=False))
        handled.append({"job_id": job_id, "status": status})
    return {"handled": handled}
