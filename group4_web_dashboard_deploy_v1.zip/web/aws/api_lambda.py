"""AWS API Gateway HTTP API (payload 2.0) -> Lambda gateway for Streamlit.

Create NEW Lambda `group4-web-api`; do not replace group4-validate/process.

Required env:
  BUCKET_NAME=group4-mfg-data-20261110
  JOB_TABLE_NAME=group4-mfg-jobs
  DEMO_API_KEY=<random server-side secret>
  PROCESS_VERSION=v1

Routes (all point to this Lambda): POST /uploads, GET /jobs/{job_id}
Use API Gateway authorizer for real deployments; x-demo-key here is an
additional course-demo guardrail, not multi-user access control.
"""
import hashlib
import hmac
import json
import os
import re
import uuid

import boto3
from botocore.config import Config
from botocore.exceptions import ClientError

BUCKET = os.environ.get("BUCKET_NAME", "")
TABLE = os.environ.get("JOB_TABLE_NAME", "")
DEMO_KEY = os.environ.get("DEMO_API_KEY", "")
VERSION = os.environ.get("PROCESS_VERSION", "v1")
MAX_BYTES = 10 * 1024 * 1024
REGION = os.environ.get("AWS_REGION", "us-east-1")
s3 = boto3.client("s3", region_name=REGION, config=Config(signature_version="s3v4"))
db = boto3.resource("dynamodb", region_name=REGION)


def _resp(status, obj):
    return {"statusCode": status, "headers": {"Content-Type": "application/json", "Cache-Control": "no-store"},
            "body": json.dumps(obj, ensure_ascii=False)}


def _sign_read(key):
    # Only S3 keys from an existing record inside our expected report prefixes.
    if not (key.startswith("reports/") or key.startswith("cleaned/")) or ".." in key:
        raise ValueError("Invalid output key")
    return s3.generate_presigned_url("get_object", Params={"Bucket": BUCKET, "Key": key}, ExpiresIn=300)


def lambda_handler(event, context):
    if not all((BUCKET, TABLE, DEMO_KEY)):
        return _resp(503, {"error": "API environment is not configured"})
    headers = {k.lower(): v for k, v in (event.get("headers") or {}).items()}
    if not hmac.compare_digest(str(headers.get("x-demo-key", "")), DEMO_KEY):
        return _resp(401, {"error": "Unauthorized"})
    ctx = event.get("requestContext", {}).get("http", {})
    method = ctx.get("method", "")
    path = event.get("rawPath", "")
    if method == "POST" and path == "/uploads":
        try:
            payload = json.loads(event.get("body") or "{}")
            filename = str(payload["filename"])
            digest = str(payload["sha256"]).lower()
            size = int(payload["size_bytes"])
            if not filename.lower().endswith(".csv") or size < 1 or size > MAX_BYTES:
                return _resp(400, {"error": "Invalid file extension or size"})
            if not re.fullmatch(r"[0-9a-f]{64}", digest):
                return _resp(400, {"error": "Invalid SHA256"})
            if payload.get("processing_version", VERSION) != VERSION:
                return _resp(400, {"error": "Unsupported processing version"})
            # Random key prevents accidental overwrites. The validation Lambda
            # computes SHA and job_id again from actual S3 bytes, not from claims.
            safe = re.sub(r"[^a-zA-Z0-9._-]", "_", filename)[:70].strip("._") or "upload.csv"
            if not safe.endswith(".csv"):
                safe = "upload.csv"
            key = f"raw/uploads/{uuid.uuid4().hex}/{safe}"
            upload_url = s3.generate_presigned_url(
                "put_object", Params={"Bucket": BUCKET, "Key": key, "ContentType": "text/csv"},
                ExpiresIn=300, HttpMethod="PUT",
            )
            job_id = hashlib.sha256(f"{digest}:{VERSION}".encode()).hexdigest()[:16]
            return _resp(200, {"job_id": job_id, "key": key, "upload_url": upload_url,
                               "upload_headers": {"Content-Type": "text/csv"}})
        except (ValueError, KeyError, TypeError, json.JSONDecodeError):
            return _resp(400, {"error": "Invalid request"})
    if method == "GET" and re.fullmatch(r"/jobs/[a-fA-F0-9]{16}", path):
        job_id = path.split("/")[-1].lower()
        try:
            record = db.Table(TABLE).get_item(Key={"job_id": job_id}, ConsistentRead=True).get("Item")
        except ClientError as exc:
            print("DynamoDB read failed", exc.response["Error"]["Code"])
            return _resp(500, {"error": "Could not read job state"})
        if not record:
            return _resp(404, {"error": "Job not found yet"})
        response = {"job_id": job_id, "status": record.get("status", "UNKNOWN"),
                    "created_at": record.get("created_at"), "updated_at": record.get("updated_at"),
                    "validation_errors": record.get("validation_errors", [])}
        if record.get("status") == "INVALID_INPUT":
            response["validation_url"] = _sign_read(f"reports/{job_id}/validation.json")
        if record.get("status") in {"COMPLETED", "COMPLETED_WITH_WARNING"}:
            if record.get("report_key"):
                response["report_url"] = _sign_read(record["report_key"])
            if record.get("cleaned_key"):
                response["cleaned_url"] = _sign_read(record["cleaned_key"])
        return _resp(200, response)
    return _resp(404, {"error": "Route not found"})
