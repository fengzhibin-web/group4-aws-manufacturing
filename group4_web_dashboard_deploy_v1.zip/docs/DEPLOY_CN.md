# Group 4 AWS Manufacturing — Web真实部署与连接（中文）

## A. 让Web先可用（不用AWS授权）

1. 在已经存放3个Lambda Zip和CloudFormation YAML的GitHub仓库中，通过 **Add file → Upload files**，上传整个 `web/` 文件夹。可同时上传本包的 `infra/`, `docs/`, `aws_artifacts/`。
2. 进入 https://share.streamlit.io ，使用GitHub账号登录 → Create app → Existing app → Repository：`fengzhibin-web/group4-aws-manufacturing` → Branch：`main` → Main file：`web/app.py` → Deploy。
3. 如果平台提示依赖文件问题，确认 `web/requirements.txt` 存在。配置Python 3.12。
4. 打开在线Web，选择“本地演示”，上传 `web/data/sample_valid.csv` 或 `web/data/manufacturing_6000.csv`，点击“本地执行分析”，确认仪表板图表和CSV/JSON下载。
5. **本地演示会在Streamlit托管的Python服务端分析数据，并没有调用AWS。** 要证明云端链路，继续B。

## B. 新增Web API（部署为第二个CloudFormation Stack）

1. 登录AWS Academy Lab，在 **us-east-1 (N. Virginia)** 确保原 `group4-mfg-stack` 在 `CREATE_COMPLETE`/`UPDATE_COMPLETE` 状态，含S3 Data Bucket、SQS、3个原有Lambda、DynamoDB；不要更新/删除它。
2. 进入S3 `group4-mfg-artifacts-20261110`，打开 `functions/`，上传本包的 `aws_artifacts/web-api-v1.zip`，完整路径必须是 `functions/web-api-v1.zip`。
3. CloudFormation → Stacks → **Create stack**（新增，而不是Update原Stack）。Upload a template file，选 `infra/group4_web_api.yaml`。
4. 栈名称：`group4-mfg-web-api-stack`；参数：
    - ArtifactBucketName：`group4-mfg-artifacts-20261110`
    - DataBucketName：`group4-mfg-data-20261110`
    - JobsTableName：`group4-mfg-jobs`
    - ExistingRoleName：`LabRole`
    - DemoApiKey：生成至少24字符随机字符串，**自己保存，不要公开/发截图/提交GitHub**。
5. 其余参数保持默认，Review创建，创建成功后进入Stack **Outputs** 复制 `ApiBaseUrl`（应为 `https://...execute-api.us-east-1.amazonaws.com`）。
6. API Gateway至少有 `POST /uploads` / `GET /jobs/{job_id}` 两条路由；Lambda列表有 `group4-web-api`。这层只提供：签名直传S3 + 查询状态/签名下载，不改主流程。
7. **失败排查**：Stack失败看Events。若为API Gateway权限不足，则Learner Lab不支持此新增服务，先用Web本地Demo + AWS Console真实处理演示，不公开S3。若为S3 NoSuchKey，检查zip存放路径。若`AccessDenied`，检查LabRole有效及其对S3 `PutObject/GetObject` 和DynamoDB `GetItem` 权限。

## C. 在线Web接通真实AWS

1. 打开 https://share.streamlit.io 的应用设置 → Secrets，填写（真实值只放在托管平台Secret管理中）：

```toml
APP_PASSWORD = "<仅组员知道的随机长密码>"
AWS_API_BASE_URL = "<CloudFormation Outputs 的 ApiBaseUrl>"
DEMO_API_KEY = "<B步骤的DemoApiKey；和APP_PASSWORD不同>"
```

2. 保存并重启应用，先输入访问密码，再选择**AWS云端模式**。
3. 上传 `web/data/sample_valid.csv`，点击“提交到AWS”；检查返回16位 `job_id`，然后点击“刷新任务状态”。
4. 期望状态：`AWAITING_EVENT → VALIDATED / QUEUED → COMPLETED`（中间状态很快，可能看不到）。若重复上传相同内容，显示之前已完成的Job是预期的幂等行为。
5. 确认报告出现后，在AWS核对：S3 `raw/uploads/...`、`cleaned/{job_id}/cleaned.csv`、`reports/{job_id}/report.json`；DynamoDB对应 `job_id`=`COMPLETED`。`reports/...` 与`cleaned/...` 的实际对象Key以DynamoDB字段为准。
6. 使用不同内容的CSV验证新任务；使用 `web/data/sample_invalid.csv` 并勾选允许无效文件，检查 `INVALID_INPUT`。如出现`FAILED`，在Web显示失败后，到Lambda/CloudWatch排障。

## D. 风险/限制

- DemoApiKey仅为**课堂演示的共享密钥**，不是正式的用户授权机制。公开应用必须先增加访问控制、API Gateway authorizer及请求限流。Streamlit密码门禁也非生产级认证。
- **AWS Academy Learner Lab重置可能清空所有云端资源**。网页本地模式能继续打开，但API地址将失效。需要先恢复原后端栈，再恢复附加Web API栈，并更新Streamlit Secrets中的新URL。
- 存储/队列/表为实时云资源；GitHub备份仅保存源码和CloudFormation模板，不会备份真实任务记录和报告。
- 不将AWS Access Key / Secret Access Key / Session Token写到Streamlit Secrets。仅API Lambda使用AWS现有LabRole通过IAM访问S3/DynamoDB；Streamlit只持有课程DemoApiKey。
- 云端实际表现需测试验证。不要把本地CSV的更细分图表描述成原有Processing Lambda输出；班次/产品/供应商等图由Web基于AWS清洗后的CSV补充计算。
