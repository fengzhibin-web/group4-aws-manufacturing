"""Group 4 / Phase 2: SQS -> process CSV -> S3 outputs + DynamoDB job states.

Deploy this entire file as lambda_function.py in group4-process.
Handler: lambda_function.lambda_handler
Environment: JOB_TABLE_NAME=group4-mfg-jobs
SQS batch size: 1. Do not suppress errors: SQS needs them for retries/DLQ.
"""
import csv
import hashlib
import io
import json
import os
import time
import uuid
from datetime import datetime, timezone
from collections import defaultdict

import boto3
from botocore.exceptions import ClientError

s3 = boto3.client("s3")
table = boto3.resource("dynamodb").Table(os.environ["JOB_TABLE_NAME"])
REQUIRED_COLUMNS = {
    "timestamp", "machine_id", "shift", "product_id",
    "supplier_batch", "temperature", "defect_label"
}


def _analyze(message):
    bucket, key, job_id = message["bucket"], message["key"], message["job_id"]
    raw = s3.get_object(Bucket=bucket, Key=key)["Body"].read()
    if hashlib.sha256(raw).hexdigest() != message["sha256"]:
        raise ValueError("S3 source object changed after validation")

    text = raw.decode("utf-8-sig")
    reader = csv.DictReader(io.StringIO(text))
    columns = list(reader.fieldnames or [])
    if not REQUIRED_COLUMNS.issubset(columns):
        raise ValueError("required columns missing during processing")

    total_rows = 0
    duplicate_rows = 0
    invalid_labels = 0
    missing_by_column = {col: 0 for col in columns}
    seen = set()
    cleaned = []
    by_machine = defaultdict(lambda: {"labeled": 0, "defects": 0})

    for row in reader:
        total_rows += 1
        cleaned_row = {col: (row.get(col) or "").strip() for col in columns}
        row_signature = tuple(cleaned_row[col] for col in columns)
        if row_signature in seen:
            duplicate_rows += 1
            continue
        seen.add(row_signature)
        cleaned.append(cleaned_row)
        for col in columns:
            if not cleaned_row[col]:
                missing_by_column[col] += 1
        label = cleaned_row["defect_label"].lower()
        if label not in {"0", "1"}:
            invalid_labels += 1  # Flag; never guess a defect label.
            continue
        machine = cleaned_row["machine_id"] or "UNKNOWN"
        by_machine[machine]["labeled"] += 1
        by_machine[machine]["defects"] += int(label)

    labeled = sum(v["labeled"] for v in by_machine.values())
    defects = sum(v["defects"] for v in by_machine.values())
    machine_stats = {
        m: {**stats,
            "defect_rate": round(stats["defects"] / stats["labeled"], 6)
            if stats["labeled"] else None}
        for m, stats in sorted(by_machine.items())
    }
    report = {
        "job_id": job_id, "status": "COMPLETED",
        "processing_version": message["processing_version"],
        "input_rows": total_rows, "cleaned_rows": len(cleaned),
        "exact_duplicates_removed": duplicate_rows,
        "invalid_defect_labels_flagged": invalid_labels,
        "missing_values_by_column": missing_by_column,
        "valid_labeled_rows": labeled, "defects": defects,
        "defect_rate": round(defects / labeled, 6) if labeled else None,
        "by_machine": machine_stats,
        "limitations": [
            "Milestone 1 computes machine-level statistics only.",
            "No causal root cause is inferred.",
        ],
    }

    out = io.StringIO()
    writer = csv.DictWriter(out, fieldnames=columns)
    writer.writeheader()
    writer.writerows(cleaned)
    s3.put_object(Bucket=bucket, Key=f"cleaned/{job_id}/cleaned.csv",
                  Body=out.getvalue().encode("utf-8"), ContentType="text/csv")
    s3.put_object(Bucket=bucket, Key=f"reports/{job_id}/report.json",
                  Body=json.dumps(report, indent=2).encode("utf-8"),
                  ContentType="application/json")
    print(json.dumps({"stage": "processing", "job_id": job_id,
                      "status": "COMPLETED", "input_rows": total_rows}))
    return report



def _now():
    return datetime.now(timezone.utc).isoformat()


def _claim_job(message):
    """Acquire a processing lease using an atomic DynamoDB condition.

    Retried messages may reclaim PROCESSING after a stale lease expires.
    A completed job is skipped without generating another report.
    """
    job_id = message["job_id"]
    token = str(uuid.uuid4())
    now_seconds = int(time.time())
    try:
        table.update_item(
            Key={"job_id": job_id},
            UpdateExpression=(
                "SET #st = :processing, lease_token = :token, "
                "lease_until = :until, updated_at = :updated"
            ),
            ConditionExpression=(
                "attribute_exists(job_id) AND sha256 = :hash "
                "AND processing_version = :version AND "
                "(#st IN (:queued, :validated) "
                "OR (#st = :processing AND lease_until < :now))"
            ),
            ExpressionAttributeNames={"#st": "status"},
            ExpressionAttributeValues={
                ":processing": "PROCESSING", ":queued": "QUEUED",
                ":validated": "VALIDATED", ":token": token,
                ":until": now_seconds + 150, ":now": now_seconds,
                ":updated": _now(), ":hash": message["sha256"],
                ":version": message["processing_version"],
            },
        )
        return token
    except ClientError as exc:
        if exc.response["Error"]["Code"] != "ConditionalCheckFailedException":
            raise
        item = table.get_item(Key={"job_id": job_id}, ConsistentRead=True).get("Item")
        if item and item.get("status") == "COMPLETED":
            print(json.dumps({"job_id": job_id, "stage": "processing",
                              "status": "DUPLICATE_SKIPPED"}))
            return None
        # Failed/invalid/locked/missing jobs are not safe to ack as success.
        # Raise so SQS retries them, and eventually moves poison messages to DLQ.
        raise RuntimeError(f"Job {job_id} is locked, missing, or not eligible to process")


def lambda_handler(event, context):
    processed = 0
    skipped = 0
    for record in event.get("Records", []):
        message = json.loads(record["body"])
        token = _claim_job(message)
        if token is None:
            skipped += 1
            continue

        # Do NOT catch errors here: with SQS batch size 1, exceptions trigger
        # queue retries. After the retry limit, SQS moves the message to DLQ.
        report = _analyze(message)
        job_id = message["job_id"]
        table.update_item(
            Key={"job_id": job_id},
            UpdateExpression=(
                "SET #st = :completed, report_key = :report, "
                "cleaned_key = :cleaned, input_rows = :rows, "
                "cleaned_rows = :cleaned_rows, updated_at = :updated "
                "REMOVE lease_until, lease_token"
            ),
            ConditionExpression="#st = :processing AND lease_token = :token",
            ExpressionAttributeNames={"#st": "status"},
            ExpressionAttributeValues={
                ":completed": "COMPLETED", ":processing": "PROCESSING",
                ":token": token,
                ":report": f"reports/{job_id}/report.json",
                ":cleaned": f"cleaned/{job_id}/cleaned.csv",
                ":rows": report["input_rows"],
                ":cleaned_rows": report["cleaned_rows"],
                ":updated": _now(),
            },
        )
        processed += 1
    return {"processed": processed, "duplicate_skipped": skipped}
