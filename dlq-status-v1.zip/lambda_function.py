"""Mark existing DynamoDB jobs FAILED when their processing message reaches the DLQ.

Event source: group4-mfg-dlq (SQS), batch size: 1.
Handler: lambda_function.lambda_handler
Environment: JOB_TABLE_NAME=group4-mfg-jobs

No fake/absent jobs are inserted. COMPLETED/INVALID_INPUT/FAILED jobs are never
changed; job_id, sha256 and processing_version must match the existing job.
"""
import json
import os
from datetime import datetime, timezone

import boto3
from botocore.exceptions import ClientError

_table = boto3.resource("dynamodb").Table(os.environ["JOB_TABLE_NAME"])


def _now():
    return datetime.now(timezone.utc).isoformat()


def _log(**fields):
    print(json.dumps(fields, ensure_ascii=False, default=str))


def _handle(record):
    message_id = record.get("messageId", "unknown")
    try:
        message = json.loads(record["body"])
    except (ValueError, KeyError, TypeError) as exc:
        # Bad envelope cannot be linked safely to a known job. Log and acknowledge.
        _log(stage="dlq_status", status="SKIPPED_BAD_JSON", message_id=message_id,
             detail=type(exc).__name__)
        return "skipped"

    if not isinstance(message, dict) or any(
        not isinstance(message.get(k), str) or not message[k]
        for k in ("job_id", "sha256", "processing_version")
    ):
        _log(stage="dlq_status", status="SKIPPED_MISSING_FIELDS",
             message_id=message_id)
        return "skipped"

    job_id = message["job_id"]
    ts = _now()
    try:
        _table.update_item(
            Key={"job_id": job_id},
            UpdateExpression=(
                "SET #st = :failed, failure_reason = :reason, "
                "failure_source = :source, failed_at = :now, "
                "updated_at = :now, dlq_message_id = :mid "
                "REMOVE lease_until, lease_token"
            ),
            ConditionExpression=(
                "attribute_exists(job_id) AND "
                "#st IN (:queued, :validated, :processing) AND "
                "#hash = :hash AND #version = :version"
            ),
            ExpressionAttributeNames={
                "#st": "status", "#hash": "sha256", "#version": "processing_version"
            },
            ExpressionAttributeValues={
                ":failed": "FAILED", ":queued": "QUEUED",
                ":validated": "VALIDATED", ":processing": "PROCESSING",
                ":reason": "MESSAGE_MOVED_TO_DLQ",
                ":source": "PROCESSING_DLQ", ":now": ts,
                ":mid": message_id, ":hash": message["sha256"],
                ":version": message["processing_version"],
            },
        )
        _log(stage="dlq_status", status="FAILED_UPDATED", job_id=job_id,
             message_id=message_id)
        return "updated"
    except ClientError as exc:
        if exc.response.get("Error", {}).get("Code") != "ConditionalCheckFailedException":
            # IAM / DynamoDB failures must be retried by SQS; do not silently ACK.
            raise
        # Condition prevents both creating fake jobs and overwriting success.
        # ConsistentRead shows the reason for the skip in CloudWatch logs.
        prior = _table.get_item(Key={"job_id": job_id}, ConsistentRead=True).get("Item")
        _log(stage="dlq_status", status="SKIPPED_NO_MATCH_OR_TERMINAL",
             job_id=job_id, existing_status=prior.get("status") if prior else "NOT_FOUND",
             message_id=message_id)
        return "skipped"


def lambda_handler(event, context):
    updated = skipped = 0
    for record in event.get("Records", []):
        outcome = _handle(record)
        if outcome == "updated":
            updated += 1
        else:
            skipped += 1
    return {"updated": updated, "skipped": skipped}
